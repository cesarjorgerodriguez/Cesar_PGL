package es.iespuertolacruz.cesarjr.institutoapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import es.iespuertolacruz.cesarjr.institutoapp.R;
import es.iespuertolacruz.cesarjr.institutoapp.adapter.AlumnoAdapter;
import es.iespuertolacruz.cesarjr.institutoapp.model.Alumno;
import es.iespuertolacruz.cesarjr.institutoapp.networking.AlumnoService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    Button btnAddAlumno;
    Button btnGetAlumnosList;
    ListView listView;
    AlumnoService alumnoService;
    List<Alumno> list = new ArrayList<Alumno>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGetAlumnosList = (Button) findViewById(R.id.btnGetAlumnosList);
        btnGetAlumnosList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getAlumnosList(v);
            }
        });

        btnAddAlumno = (Button) findViewById(R.id.btnAddAlumno);
        btnAddAlumno.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            }
        });


    }

    public void getAlumnosList(View view) {
        Call<List<Alumno>> call = alumnoService.getAlumnos();
        call.enqueue(new Callback<List<Alumno>>() {
            @Override
            public void onResponse(Call<List<Alumno>> call, Response<List<Alumno>> response) {
                if(response.isSuccessful()){
                    list = response.body();
                    listView.setAdapter(
                            new AlumnoAdapter(MainActivity.this,
                                    R.layout.listalumnos, list));
                }
            }
            @Override
            public void onFailure(Call<List<Alumno>> call, Throwable t) {
                Log.e("ERROR: ", t.getMessage());
            }
        });
    }
}
