package es.iespuertolacruz.cesarjr.institutoapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import es.iespuertolacruz.cesarjr.institutoapp.R;
import es.iespuertolacruz.cesarjr.institutoapp.model.Alumno;
import es.iespuertolacruz.cesarjr.institutoapp.networking.APIUtils;
import es.iespuertolacruz.cesarjr.institutoapp.networking.AlumnoService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AlumnoActivity extends AppCompatActivity {
    AlumnoService alumnoService;
    EditText edtAlumnoDni;
    EditText edtAlumnoName;
    EditText edtAlumnoSName;
    EditText edtAlmnoBornDate;
    Button btnSave;
    Button btnDel;
    TextView txtAlumnoDni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alumno_activity);

        setTitle("Alumnos");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtAlumnoDni = (TextView) findViewById(R.id.txtAlumnoDni);
        edtAlumnoDni = (EditText) findViewById(R.id.edtAlumnoDni);
        edtAlumnoName = (EditText) findViewById(R.id.edtUsername);
        edtAlumnoSName = (EditText) findViewById(R.id.edtAlumnoSname);
        edtAlmnoBornDate = (EditText) findViewById(R.id.edtAlumnoBornDate) ;

        btnSave = (Button) findViewById(R.id.btnSave);
        btnDel = (Button) findViewById(R.id.btnDel);

        alumnoService = APIUtils.getAlumnoService();

        Bundle extras = getIntent().getExtras();
        final String alumnoDni = extras.getString("dni");
        String alumnoName = extras.getString("nombre");
        String alumnoSecondName = extras.getString("apellidos");
        String alumnoBornDate = extras.getString("fechanacimiento");

        edtAlumnoDni.setText(alumnoDni);
        edtAlumnoName.setText(alumnoName);
        edtAlumnoSName.setText(alumnoSecondName);
        edtAlmnoBornDate.setText(alumnoBornDate);

        if(alumnoDni != null && alumnoDni.trim().length() > 0 ){
            edtAlumnoDni.setFocusable(false);
        } else {
            txtAlumnoDni.setVisibility(View.INVISIBLE);
            edtAlumnoDni.setVisibility(View.INVISIBLE);
            btnDel.setVisibility(View.INVISIBLE);
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Alumno alumno = new Alumno();
                alumno.setNombre(edtAlumnoName.getText().toString());
                alumno.setApellidos(edtAlumnoSName.getText().toString());
                alumno.setFechanacimiento(Long.parseLong(edtAlmnoBornDate.getText().toString()));
                if(alumnoDni != null && alumnoDni.trim().length() > 0){
                    //update user
                    updateAlumno(alumnoDni,alumno);
                } else {
                    //add user
                    addAlumno(alumno);
                }
            }
        });

        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAlumno(alumnoDni);

                Intent intent = new Intent(AlumnoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addAlumno(Alumno alumno){
        Call<Alumno> call = alumnoService.addAlumno(alumno);
        call.enqueue(new Callback<Alumno>() {
            @Override
            public void onResponse(Call<Alumno> call, Response<Alumno> response) {
                if(response.isSuccessful()){
                    Toast.makeText(AlumnoActivity.this, "Alumno creado con exito!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Alumno> call, Throwable t) {
                Log.e("ERROR: ", t.getMessage());
            }
        });
    }

    public void updateAlumno(String dni, Alumno alumno){
        Call<Alumno> call = alumnoService.updateUser(dni, alumno);
        call.enqueue(new Callback<Alumno>() {
            @Override
            public void onResponse(Call<Alumno> call, Response<Alumno> response) {
                if(response.isSuccessful()){
                    Toast.makeText(AlumnoActivity.this, "Alumno actualizado con exito!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Alumno> call, Throwable t) {
                Log.e("ERROR: ", t.getMessage());
            }
        });
    }

    public void deleteAlumno(String dni){
        Call<Alumno> call = alumnoService.deleteUser(dni);
        call.enqueue(new Callback<Alumno>() {
            @Override
            public void onResponse(Call<Alumno> call, Response<Alumno> response) {
                if(response.isSuccessful()){
                    Toast.makeText(AlumnoActivity.this, "Alumno eliminado correctamente!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Alumno> call, Throwable t) {
                Log.e("ERROR: ", t.getMessage());
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
