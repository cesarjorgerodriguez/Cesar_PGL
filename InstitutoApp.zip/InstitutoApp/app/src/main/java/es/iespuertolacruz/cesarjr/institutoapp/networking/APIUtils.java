package es.iespuertolacruz.cesarjr.institutoapp.networking;

import es.iespuertolacruz.cesarjr.institutoapp.networking.retrofit.RetrofitAlumno;

public class APIUtils {

    private APIUtils(){
    };

    public static final String API_URL = "http://localhost:8080/api/v1/";

    public static AlumnoService getAlumnoService(){
        return RetrofitAlumno.getAlumno(API_URL).create(AlumnoService.class);
    }
}
