package es.iespuertolacruz.cesarjr.institutoapp.database;

import android.provider.BaseColumns;

public class AlumnoContract {

    public static class AlumnoEntry implements BaseColumns {

        public static final String TABLE_NAME = "alumno";
        public static final String COLUMN_DNI = "dni";
        public static final String COLUMN_NAME = "nombre";
        public static final String COLUMN_SECOND_NAME = "apellidos";
        public static final String COLUMN_BORN_DATE = "fechanacimiento";
    }

    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + AlumnoEntry.TABLE_NAME + " (" +
                    AlumnoEntry.COLUMN_DNI + " TEXT PRIMARY KEY," +
                    AlumnoEntry.COLUMN_NAME + " TEXT," +
                    AlumnoEntry.COLUMN_SECOND_NAME + "TEXT," +
                    AlumnoEntry.COLUMN_BORN_DATE + "LONG" + ")";

    /**
     * Se define la sentencia para la eliminacion de la tabla de la bbdd
     */
    public static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + AlumnoEntry.TABLE_NAME;

    /**
     * Constructor por defecto
     */
    private AlumnoContract(){
    }
}
