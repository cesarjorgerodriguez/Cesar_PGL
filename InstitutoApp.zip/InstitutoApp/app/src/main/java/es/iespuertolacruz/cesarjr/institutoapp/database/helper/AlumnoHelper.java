package es.iespuertolacruz.cesarjr.institutoapp.database.helper;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import es.iespuertolacruz.cesarjr.institutoapp.database.AlumnoContract;
import es.iespuertolacruz.cesarjr.institutoapp.model.Alumno;

public class AlumnoHelper extends ComunHelper{

    public AlumnoHelper(Context context) {
        super(context);
    }

    public boolean add(Alumno alumno) {
        return super.add(AlumnoContract.AlumnoEntry.TABLE_NAME,
                alumno.toContentValues());
    }

    /**
     * Funcion encargada de realizar la actualizacion de un elemento
     * @param alumno con los datos a actualizar
     * @return True en caso de que la actualizacion haya sido correcta.
     * False en caso contrario
     */
    public boolean update(Alumno alumno) {
        String selection = AlumnoContract.AlumnoEntry.COLUMN_DNI + " = ?";
        String[] selectionArgs = { alumno.getNombre() };
        return super.update(
               AlumnoContract.AlumnoEntry.TABLE_NAME,
                alumno.toContentValues(),
                selection,
                selectionArgs);
    }

    /**
     * Funcion que realiza la eliminacion de un elemento sobre la table
     * @param alumno que se va a eliminar
     * @return True en caso de que la eliminación haya sido correcta. False
     * en caso contrario
     */
    public boolean delete(Alumno alumno) {
        String selection = AlumnoContract.AlumnoEntry.COLUMN_DNI + " = ?";
        String[] selectionArgs = { alumno.getDni() };
        return super.delete(
                AlumnoContract.AlumnoEntry.TABLE_NAME,
                selection,
                selectionArgs);
    }

    /**
     * Funcion que realiza la busqueda de un elemento a traves de su id
     * @param dni del usuario
     * @return con los tados del usuario
     */
    public Alumno searchOne(String dni) {
        Alumno alumno = null;
        String selection = AlumnoContract.AlumnoEntry.COLUMN_DNI + " = ?";
        String[] selectionArgs = { dni };
        Cursor cursor = super.search(AlumnoContract.AlumnoEntry.TABLE_NAME,
                null,
                selection,
                selectionArgs, null);        if (cursor != null) {
            while(cursor.moveToNext()) {
                dni = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_DNI));
                String nombre = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_NAME));
                String apellidos = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_SECOND_NAME));
                long fechanacimiento = cursor.getLong(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_BORN_DATE));
                alumno = new Alumno(dni,nombre,apellidos,fechanacimiento);
            }
            cursor.close();
        }
        return alumno;
    }

    /**
     * Funcion que realiza la busqueda de todos los usuarios
     * @return lista de usuarios
     */
    public List<Alumno> searchAll() {
        List<Alumno> usuarios = new ArrayList<>();
        Cursor cursor = super.search(AlumnoContract.AlumnoEntry.TABLE_NAME);
        if (cursor != null) {
            while(cursor.moveToNext()) {
                String dni = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_DNI));
                String nombre = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_NAME));
                String apellidos = cursor.getString(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_SECOND_NAME));
                long fechanacimiento = cursor.getLong(cursor.getColumnIndexOrThrow(
                        AlumnoContract.AlumnoEntry.COLUMN_BORN_DATE));
                Alumno alumno = new Alumno(dni,nombre, apellidos, fechanacimiento);
                usuarios.add(alumno);
            }
            cursor.close();
        }
        return usuarios;
    }
}
