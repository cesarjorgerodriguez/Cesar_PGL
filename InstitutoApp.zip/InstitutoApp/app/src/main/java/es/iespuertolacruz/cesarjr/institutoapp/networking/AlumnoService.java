package es.iespuertolacruz.cesarjr.institutoapp.networking;

import java.util.List;

import es.iespuertolacruz.cesarjr.institutoapp.model.Alumno;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface AlumnoService {
    @GET("alumno/")
    Call<List<Alumno>> getAlumnos();

    @POST("add/")
    Call<Alumno> addAlumno(@Body Alumno alumno);

    @PUT("update/{dni}")
    Call<Alumno> updateUser(@Path("dni") String id, @Body Alumno alumno);

    @DELETE("delete/{dni}")
    Call<Alumno> deleteUser(@Path("dni") String dni);
}
