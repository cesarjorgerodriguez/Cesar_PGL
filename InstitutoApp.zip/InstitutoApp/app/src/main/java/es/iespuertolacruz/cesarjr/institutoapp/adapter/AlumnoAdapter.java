package es.iespuertolacruz.cesarjr.institutoapp.adapter;

import android.content.Context;
import android.widget.ArrayAdapter;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;

import java.util.List;

import es.iespuertolacruz.cesarjr.institutoapp.model.Alumno;

public class AlumnoAdapter extends ArrayAdapter<Alumno> {
    private Context context;
    private List<Alumno> alumnos;

    public AlumnoAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Alumno> objects) {
        super(context, resource, objects);
        this.context = context;
        this.alumnos = objects;
    }


}
