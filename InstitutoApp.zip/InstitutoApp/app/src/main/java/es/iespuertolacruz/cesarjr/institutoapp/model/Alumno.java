package es.iespuertolacruz.cesarjr.institutoapp.model;

import android.content.ContentValues;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import es.iespuertolacruz.cesarjr.institutoapp.database.AlumnoContract;

public class Alumno {
    @SerializedName("dni")
    @Expose
    private String dni;

    @SerializedName("nombre")
    @Expose
    private String nombre;

    @SerializedName("apellidos")
    @Expose
    private String apellidos;

    @SerializedName("fechanacimiento")
    @Expose
    private long fechanacimiento;

    public Alumno() {
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public long getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(long fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public Alumno(String dni, String nombre, String apellidos, long fechanacimiento) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechanacimiento = fechanacimiento;
    }

    public ContentValues toContentValues(){
        ContentValues values = new ContentValues();
        values.put(AlumnoContract.AlumnoEntry.COLUMN_DNI,this.dni);
        values.put(AlumnoContract.AlumnoEntry.COLUMN_NAME,this.nombre);
        values.put(AlumnoContract.AlumnoEntry.COLUMN_SECOND_NAME,this.apellidos);
        values.put(AlumnoContract.AlumnoEntry.COLUMN_BORN_DATE,this.fechanacimiento);
        return values;
    }
}
